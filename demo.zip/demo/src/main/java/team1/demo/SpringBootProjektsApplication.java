package team1.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootProjektsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootProjektsApplication.class, args);
	}

}
