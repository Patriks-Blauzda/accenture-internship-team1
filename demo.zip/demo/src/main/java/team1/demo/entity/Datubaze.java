package team1.demo.entity;


import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@javax.persistence.Entity
public class Datubaze {

    @Id
    @GeneratedValue
    private int Nr;
    private String Ievaditie_dati;

    public Datubaze(){

    }

    public int getNr() {
        return Nr;
    }

    public void setNr(int Nr) {
        this.Nr = Nr;
    }

    public String getIevaditie_dati() {
        return Ievaditie_dati;
    }

    public void setIevaditie_dati(String Ievaditie_dati) {
        this.Ievaditie_dati = Ievaditie_dati;
    }
}
